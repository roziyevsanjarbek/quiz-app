<header>
    <div class="container">
        <div class="header-content">
            <div class="logo">
                <span class="logo-icon">📚</span>
                <span class="logo-text">QuizMaster</span>
            </div>
            <nav>
                <a href="/">Bosh sahifa</a>
                <a href="/quizzes">Quizlar</a>
                <a href="#">Biz haqimizda</a>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH /home/sanjarbek/project/quiz-app/resources/views/components/home-navbar.blade.php ENDPATH**/ ?>