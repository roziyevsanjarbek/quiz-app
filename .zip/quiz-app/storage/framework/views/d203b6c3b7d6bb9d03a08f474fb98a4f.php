<aside class="sidebar">
    <div class="sidebar-header">
        <span class="logo-icon">📚</span>
        <span class="logo-text">QuizMaster</span>
    </div>
    <nav class="sidebar-nav">
        <a href="<?php echo e(route('dashboard')); ?>" class="nav-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
            <span class="nav-icon">🏠</span>
            <span class="nav-label">Dashboard</span>
        </a>

        <a href="<?php echo e(route('my-quizzes')); ?>" class="nav-item <?php echo e(request()->routeIs('my-quizzes') ? 'active' : ''); ?>">
            <span class="nav-icon">📋</span>
            <span class="nav-label">My Quizzes</span>
        </a>

        <a href="<?php echo e(route('add-quizzes')); ?>" class="nav-item <?php echo e(request()->routeIs('add-quizzes') ? 'active' : ''); ?>">
            <span class="nav-icon">✍️</span>
            <span class="nav-label">Create Quiz</span>
        </a>
        <a href="<?php echo e(route('upload-quiz')); ?>" class="nav-item <?php echo e(request()->routeIs('upload-quiz') ? 'active' : ''); ?>">
            <span class="nav-icon">⬆️</span>
            <span class="nav-label">Fayl Yuklash</span>
        </a>
    </nav>
</aside>
<?php /**PATH /home/sanjarbek/project/quiz-app/resources/views/components/sidebar.blade.php ENDPATH**/ ?>