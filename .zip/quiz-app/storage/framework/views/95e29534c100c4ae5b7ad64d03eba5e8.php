<?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<div class="app-layout">
    <!-- Sidebar -->
    <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>


    <!-- Main Content -->
    <main class="main-content">
        <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>


        <div class="create-quiz-content">
            <form class="quiz-form">
                <section class="form-section">
                    <h3>Quiz Details</h3>
                    <div class="form-group">
                        <label for="quiz-title">Quiz Title</label>
                        <input type="text" id="quiz-title" placeholder="Enter quiz title" required>
                    </div>
                    <div class="form-group">
                        <label for="quiz-desc">Description</label>
                        <textarea id="quiz-desc" placeholder="Describe your quiz" rows="4"></textarea>
                    </div>
                </section>

                <section class="form-section">
                    <h3>Add Questions</h3>
                    <div class="questions-list">
                        <div class="question-form">
                            <div class="form-group">
                                <label>Question 1</label>
                                <input type="text" placeholder="Enter your question" class="question-input">
                            </div>
                            <div class="options-group">
                                <div class="form-group">
                                    <label>Option A</label>
                                    <div class="option-input-wrapper">
                                        <input type="text" placeholder="Option A">
                                        <input type="radio" name="answer1" value="a">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Option B</label>
                                    <div class="option-input-wrapper">
                                        <input type="text" placeholder="Option B">
                                        <input type="radio" name="answer1" value="b">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Option C</label>
                                    <div class="option-input-wrapper">
                                        <input type="text" placeholder="Option C">
                                        <input type="radio" name="answer1" value="c">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Option D</label>
                                    <div class="option-input-wrapper">
                                        <input type="text" placeholder="Option D">
                                        <input type="radio" name="answer1" value="d">
                                    </div>
                                </div>
                            </div>
                            <small>Select the correct answer</small>
                        </div>
                    </div>
                    <button id="addQuestionBtn" type="button" class="btn btn-secondary btn-small add-question-btn">+ Add Question</button>
                </section>

                <div class="form-actions">
                    <a href="<?php echo e(route('my-quizzes')); ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Quiz</button>
                </div>
            </form>
        </div>
    </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

<script>

    const questionsList = document.querySelector('.questions-list');
    let questionCount = 1;

    document.querySelector('.add-question-btn').addEventListener('click', function() {
        questionCount++;

        const questionForm = document.createElement('div');
        questionForm.classList.add('question-form');
        questionForm.innerHTML = `
        <div class="form-group">
            <label>Question ${questionCount}</label>
            <input type="text" placeholder="Enter your question" class="question-input">
        </div>
        <div class="options-group">
            ${['A','B','C','D'].map(letter => `
                <div class="form-group">
                    <label>Option ${letter}</label>
                    <div class="option-input-wrapper">
                        <input type="text" placeholder="Option ${letter}">
                        <input type="radio" name="answer${questionCount}" value="${letter.toLowerCase()}">
                    </div>
                </div>
            `).join('')}
        </div>
        <small>Select the correct answer</small>
    `;

        questionsList.appendChild(questionForm);
    });


    document.addEventListener("DOMContentLoaded", function() {
        const urlParams = new URLSearchParams(window.location.search);
        const quizId = urlParams.get('quiz_id');
        const token = localStorage.getItem('token');

        axios.get(`/api/quizzes/${quizId}`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        })
            .then(response => {
                const quiz = response.data.quiz;

                // Title va description
                document.getElementById('quiz-title').value = quiz.title;
                document.getElementById('quiz-desc').value = quiz.description || '';

                // Savollarni formga joylash
                const questionsList = document.querySelector('.questions-list');
                questionsList.innerHTML = '';
                let questionCount = 0;

                quiz.questions.forEach(q => {
                    questionCount++;
                    const questionForm = document.createElement('div');
                    questionForm.classList.add('question-form');
                    questionForm.innerHTML = `
                <div class="form-group">
                    <label>Question ${questionCount}</label>
                    <input type="text" placeholder="Enter your question" class="question-input" value="${q.question_text}">
                </div>
                <div class="options-group">
                    ${q.options.map((opt, index) => {
                        const letter = String.fromCharCode(65 + index);
                        return `
                            <div class="form-group">
                                <label>Option ${letter}</label>
                                <div class="option-input-wrapper">
                                    <input type="text" placeholder="Option ${letter}" value="${opt.option_text}">
                                    <input type="radio" name="answer${questionCount}" value="${letter.toLowerCase()}" ${opt.is_correct ? 'checked' : ''}>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
                <small>Select the correct answer</small>
            `;
                    questionsList.appendChild(questionForm);
                });
            })
            .catch(err => {
                console.error(err.response?.data || err);
                alert('Failed to load quiz data.');
            });
    });

    document.querySelector('.quiz-form').addEventListener('submit', function(e) {
        e.preventDefault(); // Default form submitni to'xtatamiz

        const urlParams = new URLSearchParams(window.location.search);
        const quizId = urlParams.get('quiz_id');
        const token = localStorage.getItem('token');

        // Title va description
        const title = document.getElementById('quiz-title').value;
        const description = document.getElementById('quiz-desc').value;

        // Savollar va ularning variantlarini yig‘ish
        const questions = [];
        const questionForms = document.querySelectorAll('.question-form');

        questionForms.forEach((qForm, qIndex) => {
            const questionText = qForm.querySelector('.question-input').value;
            const optionsInputs = qForm.querySelectorAll('.options-group .option-input-wrapper');

            const options = [];
            optionsInputs.forEach(optDiv => {
                const text = optDiv.querySelector('input[type="text"]').value;
                const isCorrect = optDiv.querySelector('input[type="radio"]').checked ? 1 : 0;
                options.push({ option_text: text, is_correct: isCorrect });
            });

            questions.push({
                question_text: questionText,
                type: 'multiple_choice',
                options: options
            });
        });

        // Axios POST request
        axios.post(`/api/quizzes/${quizId}`, {
            title,
            description,
            questions
        }, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        })
            .then(response => {
                alert('Quiz updated successfully!');
                window.location.href = '/my-quizzes';
            })
            .catch(err => {
                console.error(err.response?.data || err);
                alert('Failed to update quiz.');
            });
    });


</script>
<?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php /**PATH /home/sanjarbek/project/quiz-app/resources/views/update-quiz.blade.php ENDPATH**/ ?>