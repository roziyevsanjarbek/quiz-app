<?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<div class="app-layout">
    <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
    <main class="main-content">
        <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>

        <div class="quizzes-content">

            <div class="quizzes-grid" id="quizzesGrid">
                <!-- Quizlar JS orqali shu yerga qo‘shiladi -->
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    const quizzesGrid = document.getElementById('quizzesGrid');
    const token = localStorage.getItem('token'); // Sanctum / Passport token

    async function fetchQuizzes() {
        try {
            const response = await axios.get('/api/quizzes', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Accept': 'application/json'
                }
            });

            const quizzes = response.data.quizzes;
            quizzesGrid.innerHTML = ''; // avvalgi quizlarni tozalash

            quizzes.forEach(quiz => {
                const quizCard = document.createElement('div');
                quizCard.classList.add('quiz-card');
                quizCard.innerHTML = `
                    <div class="quiz-card-header">
                        <h3>${quiz.title}</h3>
                    </div>
                    <p class="quiz-desc">${quiz.description || ''}</p>
                    <div class="quiz-meta">
                        <span>Created: ${new Date(quiz.created_at).toLocaleDateString()}</span>
                        <span class="quiz-status">${quiz.status ?? 'Draft'}</span>
                    </div>
                    <div class="quiz-card-actions">
                        <button class="btn btn-small btn-secondary edit-btn" data-id="${quiz.id}">Edit</button>
                        <button class="btn btn-small btn-secondary delete-btn" data-id="${quiz.id}">Delete</button>
                        <button class="btn btn-small btn-primary take-btn" data-id="${quiz.id}">Take</button>
                    </div>
                `;
                quizzesGrid.appendChild(quizCard);
            });
        } catch (error) {
            console.error(error.response?.data || error);
            quizzesGrid.innerHTML = '<p>Failed to load quizzes.</p>';
        }
    }

    fetchQuizzes();

    document.addEventListener("DOMContentLoaded", function() {
        const quizzesGrid = document.getElementById("quizzesGrid"); // sizning quiz container

        // Dinamik Edit buttonlar uchun event delegation
        quizzesGrid.addEventListener("click", function(e) {
            if (e.target && e.target.classList.contains("edit-btn")) {
                const quizId = e.target.getAttribute("data-id");
                // Yangi sahifaga yo'naltirish
                window.location.href = `/update-quizzes?quiz_id=${quizId}`;
            }
        });
    });

    // Filter tugmalari
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            const filter = this.dataset.filter;
            const quizCards = document.querySelectorAll('.quiz-card');

            quizCards.forEach(card => {
                const status = card.querySelector('.quiz-status').textContent.toLowerCase();
                if (filter === 'all') {
                    card.style.display = 'block';
                } else if (filter === 'published' && status === 'published') {
                    card.style.display = 'block';
                } else if (filter === 'mine') {
                    // Agar kerak bo‘lsa, 'created_by_me' flag backenddan qo‘shish mumkin
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });


    document.addEventListener("DOMContentLoaded", function() {
        const quizzesGrid = document.getElementById("quizzesGrid");
        const token = localStorage.getItem('token');

        // Quizzesni fetch qilish
        fetchQuizzes();

        // Dinamik Edit va Delete buttonlar uchun event delegation
        quizzesGrid.addEventListener("click", function(e) {
            const quizId = e.target.getAttribute("data-id");

            // Edit button
            if (e.target.classList.contains("edit-btn")) {
                window.location.href = `http://localhost:8000/update-quizzes?quiz_id=${quizId}`;
            }

            // Delete button
            if (e.target.classList.contains("delete-btn")) {
                if (!confirm("Are you sure you want to delete this quiz?")) return;

                axios.delete(`/api/quizzes/${quizId}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Accept': 'application/json'
                    }
                })
                    .then(res => {
                        alert(res.data.message);
                        // Quiz DOMdan o'chirish
                        e.target.closest('.quiz-card').remove();
                    })
                    .catch(err => {
                        console.error(err.response?.data || err);
                        alert('Failed to delete quiz.');
                    });
            }

            // Take quiz button (misol uchun)
            if (e.target.classList.contains("take-btn")) {
                window.location.href = `/take-quiz/${quizId}`;
            }
        });
    });


</script>
<?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php /**PATH /home/sanjarbek/project/quiz-app/resources/views/my-quizzes.blade.php ENDPATH**/ ?>