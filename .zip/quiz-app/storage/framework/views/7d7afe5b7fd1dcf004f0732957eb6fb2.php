</body>
</html>
<?php /**PATH /home/sanjarbek/project/quiz-app/resources/views/components/footer.blade.php ENDPATH**/ ?>